---
name: motion-design
description: Preserve and selectively enhance PowerPoint native animation and transition timing.
---

# Workflow

Gate: inspect animation-inventory and obtain approval before replacing/removing motion. Preserve timing tree, IDs, triggers, builds, AlternateContent branches and relationships. Prefer native minimal effects; do not add loop motion to Honeycomb by assuming Living_Cubes history. Test scoped OOXML roundtrip on a disposable approved copy. Static PDF does not verify motion. Record Desktop test limitations.

Read the project AGENTS.md before acting. The latest explicit user scope governs all actions. No unapproved installations, external access, or publication.
