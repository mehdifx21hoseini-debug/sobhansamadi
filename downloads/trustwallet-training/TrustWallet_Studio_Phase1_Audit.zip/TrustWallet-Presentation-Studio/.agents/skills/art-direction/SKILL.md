---
name: art-direction
description: Derive and refine the original TrustWallet visual identity after approval.
---

# Workflow

Read baseline tokens and original slides. Preserve turquoise/green/white, honeycomb, logo and locked footer. Differentiate observations from proposals. Propose hierarchy, spacing and image language with restraint. Do not change the design system until approved. Select three representative samples without creating them before sample authorization.

Read the project AGENTS.md before acting. The latest explicit user scope governs all actions. No unapproved installations, external access, or publication.
