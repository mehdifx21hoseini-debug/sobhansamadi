---
name: slide-design
description: Design approved editable PowerPoint samples and small batches without changing content.
---

# Workflow

Gate: explicit approval for this phase. Work only on working copies. Preserve slide count/order/text/notes/image-contained educational content. Keep real UI genuine; native text/shapes editable. Never flatten whole slides. Preserve footer exactly. Design three approved samples first; pause for approval before production batches. Log every changed part.

Read the project AGENTS.md before acting. The latest explicit user scope governs all actions. No unapproved installations, external access, or publication.
