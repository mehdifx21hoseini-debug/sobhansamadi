---
name: presentation-audit
description: Read-only PPTX content, media, fonts, relationships, native animation and environment audit.
---

# Workflow

Inspect ZIP/XML before selecting an editing engine. Hash source and backup; extract slide order, all XML text/runs and notes, inherited layout/master elements, images/crops/PPI, fonts, timing branches and relationships. Never save the source with python-pptx. Flag picture-contained text as unverified unless visually transcribed. Export JSON manifests and concise findings. Phase1 ends at report and approval.

Read the project AGENTS.md before acting. The latest explicit user scope governs all actions. No unapproved installations, external access, or publication.
