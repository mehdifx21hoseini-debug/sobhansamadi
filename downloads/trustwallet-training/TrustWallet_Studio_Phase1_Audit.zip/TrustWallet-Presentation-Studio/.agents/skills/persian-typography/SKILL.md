---
name: persian-typography
description: Inspect Persian RTL typography, fonts and text fidelity in the original deck.
---

# Workflow

Vazirmatn is the baseline. Inspect RTL, complex script fonts, embedded fonts and rendering. Preserve text literally, including numbers and punctuation. Report suspected spelling or bidi problems instead of silently rewriting. Any Estedad experiment needs sample-phase approval and no system font installation without approval. Visual rendering is required to verify shaping.

Read the project AGENTS.md before acting. The latest explicit user scope governs all actions. No unapproved installations, external access, or publication.
