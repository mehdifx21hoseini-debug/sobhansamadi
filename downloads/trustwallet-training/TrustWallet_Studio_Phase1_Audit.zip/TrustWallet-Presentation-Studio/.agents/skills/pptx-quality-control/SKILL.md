---
name: pptx-quality-control
description: Check PPTX structural integrity, content preservation, branding and rendering.
---

# Workflow

Compare source hashes, slide order/count, text/runs/notes, media bytes/crops, layouts/master/footer geometry, embedded font parts, timing/transition XML and relationships. Run ZIP CRC and XML target checks. Render only to static previews during audit; never re-export source to PPTX. Inspect full-slide previews; do not claim full OCR or Windows compatibility from LibreOffice. Score only approved design batches with evidence; fidelity is mandatory.

Read the project AGENTS.md before acting. The latest explicit user scope governs all actions. No unapproved installations, external access, or publication.
