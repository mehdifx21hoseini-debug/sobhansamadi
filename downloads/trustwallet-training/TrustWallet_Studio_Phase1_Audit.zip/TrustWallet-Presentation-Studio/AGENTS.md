# TrustWallet Presentation Studio — Codex

## Authority and current scope
The latest explicit user instruction overrides the archived master prompt. Current authorization is PHASE 1 ONLY: read-only audit, manifests, environment inventory, project scaffolding, and an execution plan. Do not create a new PPTX, change slide content/design/order/count, or perform a save/re-export of the source. No current authorization for bulk design or sample production.

## Preservation
- `source/original.pptx` is authoritative; preserve byte-for-byte and read-only. `source/original.backup.pptx` is an identical backup. Record SHA-256 before and after each phase.
- Preserve every text run, note, number, image and image-contained text, chart, diagram, relationship, embedded font, animation, transition, interaction, and editable element unless the user approves the specific change.
- Preserve original turquoise/green/white branding, honeycomb, logo, footer geometry/content/style, RTL text, and typography. Distinguish observed tokens from proposed changes.
- Do not reconstruct real product UI. Mark image-contained text as requiring visual verification when extraction is unavailable. Never invent missing content or claim OCR is complete.

## Codex execution
Use `.agents/skills/<skill>/SKILL.md` for specialized workflows. No Claude-specific paths or commands. The orchestrator assigns bounded tasks to available Codex subagents; otherwise runs separate role stages. Agents write only assigned reports and never mutate the source. No secrets in artifacts.

## Approval gates
Report and wait for explicit user approval before each major next phase: design system, three sample slides, approved small production batches, final release. Do not infer current approval from historical approvals of other versions. No dependency installation, paid tools, external account activation, or external access without approval. No public upload under this phase.

## Engineering
Inspect OOXML before selecting an engine. Use ZIP/XML and python-pptx for read-only inventory. Do not treat library round-trips, LibreOffice re-export, or PptxGenJS reconstruction as lossless. Prefer scoped OOXML edits on working copies only AFTER approval and preservation tests. Require PowerPoint compatibility testing; LibreOffice static rendering is not proof of PowerPoint animation playback. Report unavailable Windows testing honestly.

## Project boundaries and QA
Reports: analysis/; baseline extraction: analysis/; visual previews: previews/; scripts: production/scripts/; checks: qa/; approved final deliverables: output/. No final deck in Phase 1.
Content fidelity is a hard pass/fail gate. Compare text, notes, part hashes, media, font and timing inventories, relationships, footer geometry, and slide order. Future design score weights: aesthetics25, consistency20, typography15, images15, motion10, fidelity15; minimum90 and mandatory fidelity pass. Do not assign a score without supporting review.
