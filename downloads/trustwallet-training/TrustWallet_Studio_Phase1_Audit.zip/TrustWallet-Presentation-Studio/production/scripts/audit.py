from pathlib import Path
from collections import Counter
from zipfile import ZipFile
from lxml import etree as E
import hashlib,json,platform,subprocess,shutil,importlib.metadata as md,os,posixpath
from pptx import Presentation
ROOT=Path(__file__).resolve().parents[2];src=ROOT/'source/original.pptx'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):p=ROOT/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
for d in ['design-system/layouts','assets/images','assets/icons','assets/illustrations','assets/fonts','production/components','previews','output']:(ROOT/d).mkdir(parents=True,exist_ok=True)
ns={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
p=Presentation(src);colors=Counter();fonts=Counter();sizes=Counter();slides=[];anims=[];parts=[];images={};issues=[]
with ZipFile(src) as z:
 assert z.testzip() is None
 for n in z.namelist():
  b=z.read(n);parts.append({'part':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
  if n.endswith('.xml'):
   r=E.fromstring(b)
   for c in r.xpath('//a:srgbClr/@val',namespaces=ns):colors[c]+=1
  if n.startswith('ppt/media/'):
   out=ROOT/'assets/images'/Path(n).name;out.write_bytes(b)
   images[n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'image_text_status':'not OCR verified; retain original bytes'}
 for i,s in enumerate(p.slides,1):
  part=str(s.part.partname).lstrip('/');r=E.fromstring(z.read(part));shapes=[]
  for a in s.shapes:
   el=E.fromstring(E.tostring(a._element))
   runs=[]
   for t in el.xpath('.//a:r',namespaces=ns):
    props=t.find('a:rPr',ns);txt=''.join(t.xpath('./a:t/text()',namespaces=ns))
    data={'text':txt,'properties_xml':E.tostring(props).decode() if props is not None else None};runs.append(data)
    if props is not None:
     for f in props.xpath('./a:latin/@typeface|./a:ea/@typeface|./a:cs/@typeface',namespaces=ns):fonts[f]+=1
     if props.get('sz'):sizes[props.get('sz')]+=1
   item={'id':a.shape_id,'name':a.name,'type':str(a.shape_type),'bounds_emu':[a.left,a.top,a.width,a.height],'text':a.text if a.has_text_frame else None,'all_text_nodes':el.xpath('.//a:t/text()',namespaces=ns),'runs':runs,'xml':E.tostring(el).decode()}
   if a.shape_type==13:
    item['image']={'sha256':hashlib.sha256(a.image.blob).hexdigest(),'dimensions':a.image.size,'format':a.image.ext,'crop':[a.crop_left,a.crop_top,a.crop_right,a.crop_bottom],'effective_ppi':[round(a.image.size[0]/(a.width/914400),1),round(a.image.size[1]/(a.height/914400),1)]}
   if a.has_table:item['table']=[[c.text for c in row.cells] for row in a.table.rows]
   if a.has_chart:item['chart']=True
   if a.left<0 or a.top<0 or a.left+a.width>p.slide_width or a.top+a.height>p.slide_height:item['outside_canvas']=True
   shapes.append(item)
  notes=s.notes_slide.notes_text_frame.text if s.has_notes_slide else None
  rels=[{'id':rel.rId,'type':rel.reltype,'external':rel.is_external,'target':rel.target_ref} for rel in s.part.rels.values()]
  title=next((a.text for a in s.shapes if a.name in ['title','benT'] and a.has_text_frame),' / '.join(a.text for a in s.shapes if a.has_text_frame and a.text.strip())[:100])
  slides.append({'number':i,'part':part,'title':title,'layout':str(s.slide_layout.part.partname),'layout_name':s.slide_layout.name,'master':str(s.slide_layout.slide_master.part.partname),'notes':notes,'shapes':shapes,'relationships':rels})
  timing=r.xpath('//p:timing',namespaces=ns);trans=r.xpath('//p:transition',namespaces=ns)
  ai={'slide':i,'part':part,'timing_count':len(timing),'timing_xml':[E.tostring(x).decode() for x in timing],'transitions':[{'attributes':dict(x.attrib),'effect_children':[E.QName(c).localname for c in x]} for x in trans],'effect_counts':dict(Counter(E.QName(x).localname for x in r.xpath('//p:anim|//p:animEffect|//p:animMotion|//p:animRot|//p:animScale|//p:set',namespaces=ns))),'targets':r.xpath('//p:spTgt/@spid',namespaces=ns),'time_nodes':[dict(x.attrib) for x in r.xpath('//p:cTn',namespaces=ns)]}
  ids=set(r.xpath('//p:cNvPr/@id',namespaces=ns));bad=set(ai['targets'])-ids
  if bad:issues.append({'slide':i,'invalid_animation_targets':list(bad)})
  anims.append(ai)
 # Validate all internal relationships, not just slides.
 missing=[];external=[]
 for n in z.namelist():
  if not n.endswith('.rels'):continue
  r=E.fromstring(z.read(n));base='' if n=='_rels/.rels' else posixpath.dirname(posixpath.dirname(n))
  for rel in r:
   target=rel.get('Target')
   if rel.get('TargetMode')=='External':external.append({'part':n,'type':rel.get('Type'),'target':target});continue
   resolved=posixpath.normpath(posixpath.join(base,target)) if not target.startswith('/') else target.lstrip('/')
   if resolved not in z.namelist():missing.append({'part':n,'target':target,'resolved':resolved})
 media_types=Counter(Path(n).suffix for n in images)
 embedded=[n for n in z.namelist() if n.startswith('ppt/fonts/')]
 advanced={key:[n for n in z.namelist() if pattern in n] for key,pattern in [('charts','ppt/charts/'),('smartart','ppt/diagrams/'),('embeddings','ppt/embeddings/'),('vba','vbaProject'),('comments','ppt/comments/')]}
write('analysis/content-manifest.json',{'source_sha256':digest(src),'slide_size_emu':[p.slide_width,p.slide_height],'slides':slides,'image_text_limitation':'All image bytes and XML text preserved in inventory. Text drawn inside pictures is not exhaustively transcribed. Requires human visual verification. No OCR claim.'})
write('analysis/slide-inventory.json',[{k:v for k,v in s.items() if k!='shapes'}|{'shape_count':len(s['shapes']),'text_shapes':sum(bool(a['text']) for a in s['shapes']),'picture_count':sum('image'in a for a in s['shapes']),'outside_canvas':[a['name'] for a in s['shapes'] if a.get('outside_canvas')]} for s in slides])
write('analysis/animation-inventory.json',anims);write('analysis/part-hashes.json',parts);write('analysis/image-inventory.json',images)
write('qa/relationship-audit.json',{'missing_internal_targets':missing,'external_relationships':external,'invalid_animation_targets':issues})
write('design-system/color-palette.json',{'status':'OBSERVED, not an approved redesign','srgb_usage':colors.most_common()});write('design-system/typography.json',{'status':'OBSERVED','explicit_run_font_usage':fonts.most_common(),'explicit_size_hundredths_pt':sizes.most_common(),'embedded_font_parts':embedded,'caution':'Font references can also inherit from theme/layout/master; explicit run counts are not unique text counts.'})
write('design-system/tokens.json',{'status':'baseline only; no design decisions changed','slide_size_emu':[p.slide_width,p.slide_height],'footer_band':'preserve existing geometry and assets; no redesign authorization','source_sha256':digest(src)})
versions={}
for x in ['python','node','npm','git','soffice','codex','fc-list','pdftoppm','tesseract']:
 exe=shutil.which(x);row={'path':exe}
 if exe:
  res=subprocess.run([exe,'--version'],capture_output=True,text=True);row['version']=(res.stdout+res.stderr)[:800]
 versions[x]=row
packages={}
for x in ['python-pptx','lxml','Pillow','PyMuPDF','defusedxml','fonttools','matplotlib','numpy']:
 try:packages[x]=md.version(x)
 except md.PackageNotFoundError:packages[x]=None
fc=subprocess.run(['fc-list',':','family','file'],capture_output=True,text=True);(ROOT/'analysis/fonts-installed.txt').write_text(fc.stdout)
node=subprocess.run(['node','-e',"for(const x of ['pptxgenjs','sharp','svgo']){try{console.log(x,require.resolve(x))}catch(e){console.log(x,'NOT RESOLVABLE')}}"],capture_output=True,text=True)
write('analysis/environment.json',{'os':platform.platform(),'project_root':str(ROOT),'executables':versions,'python_packages':packages,'node_modules_probe':node.stdout,'codex_capabilities':'Codex tool orchestration, shell, file edits and explicitly authorized subagents available. CLI version is installed binary version, not proof of orchestrator runtime version.','powerpoint_desktop':'not available on this Linux environment','installations_performed':[],'external_access_performed':False})
write('qa/source-integrity.json',{'source_sha256':digest(src),'backup_sha256':digest(ROOT/'source/original.backup.pptx'),'same_as_uploaded':digest(src)==digest(Path('/workspace/attachments/1d8e3ade-a35b-48df-95a6-8ea435c65466/TrustWallet_Honeycomb.pptx')),'source_mode':oct(src.stat().st_mode & 0o777),'new_pptx_created':False})
summary={'slide_count':len(slides),'shapes':sum(len(s['shapes']) for s in slides),'pictures':sum('image'in a for s in slides for a in s['shapes']),'unique_media':len(images),'media_types':dict(media_types),'font_parts':len(embedded),'slides_with_timing':sum(bool(x['timing_count']) for x in anims),'slides_with_transition':sum(bool(x['transitions']) for x in anims),'motion_paths':sum(x['effect_counts'].get('animMotion',0) for x in anims),'advanced':advanced,'missing_rel_targets':len(missing),'invalid_anim_targets':len(issues),'fonts':fonts.most_common(),'source_sha256':digest(src)}
write('analysis/summary.json',summary)
lines=['# فهرست محتوای اسلایدها','متن‌های قابل استخراج از XML و یادداشت مدرس؛ متن داخل تصویر نیازمند بازبینی تصویری است.']
for s in slides:
 lines+=['',f"## {s['number']}. {s['title']}"]
 for a in s['shapes']:
  if a['text'] and a['text'].strip():lines.append(a['text'])
 if s['notes']:lines+=['','یادداشت مدرس:',s['notes']]
(ROOT/'analysis/content-manifest.md').write_text('\n\n'.join(lines),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
