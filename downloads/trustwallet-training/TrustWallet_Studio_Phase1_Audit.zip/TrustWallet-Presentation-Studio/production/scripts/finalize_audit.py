from pathlib import Path
import json,hashlib,zipfile
from lxml import etree as E
r=Path(__file__).resolve().parents[2];ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main'}
def write(n,x):(r/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(r/'source/original.pptx') as z:
 inherited=[]
 for n in z.namelist():
  if n.startswith(('ppt/slideLayouts/slideLayout','ppt/slideMasters/slideMaster','ppt/theme/theme')) and n.endswith('.xml'):
   root=E.fromstring(z.read(n));inherited.append({'part':n,'texts':root.xpath('//a:t/text()',namespaces=ns),'fonts':root.xpath('//a:latin/@typeface|//a:cs/@typeface|//a:ea/@typeface',namespaces=ns),'xml':z.read(n).decode()})
 write('analysis/inherited-design-manifest.json',inherited)
inv=json.loads((r/'analysis/slide-inventory.json').read_text())
for s in inv:
 i=s['number'];s['review_status']='Static overview reviewed; detailed per-object overlap and image-text transcription not certified'
 s['potential_issues']=['بخشی از مکعب‌ها عمداً خارج کادر ذخیره شده‌اند؛ حذف خودکار ممنوع.'] if s['outside_canvas'] else []
 if i in [8,10,24,26,27,29,32]:s['potential_issues'].append('برخی گزاره‌های فنی/زمان‌مند نیازمند تأیید مدرس و بررسی در مرحله بعدند؛ متن تغییر نکرد.')
 if 15<=i<=23:s['potential_issues'].append('متن داخل عکس گوشی تصویری است؛ اصالت رابط و خوانایی در بزرگ‌نمایی باید بازبینی شود.')
 s['proposed_enhancement']='پس از تأیید: تنظیم فاصله‌ها و سلسله‌مراتب در همین قالب؛ حفظ کامل متن و فوتر.'
write('analysis/slide-inventory.json',inv)
write('qa/static-preview-review.json',{'pages_rendered':33,'overview_contact_sheets_reviewed':[1,2,3],'method':'LibreOffice PDF export only; source not re-exported as PPTX; PyMuPDF PNG previews','findings':['Original turquoise/green/white identity, honeycomb and footer present throughout the overview.','Nine phone lessons15–23 retained; cover and closing remain original.','Overview does not certify all small text, all image text, detailed overlaps or animation playback.'],'powerpoint_playback_tested':False})
base=r/'source/original.pptx';backup=r/'source/original.backup.pptx';uploaded=Path('/workspace/attachments/1d8e3ade-a35b-48df-95a6-8ea435c65466/TrustWallet_Honeycomb.pptx');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(base)==h(backup)==h(uploaded)
write('qa/source-integrity.json',{'source_sha256':h(base),'backup_sha256':h(backup),'uploaded_sha256':h(uploaded),'unchanged_after_audit':True,'source_mode':oct(base.stat().st_mode&0o777),'pptx_files_created':['source/original.pptx (byte-identical reference copy)','source/original.backup.pptx (byte-identical backup)'],'new_or_modified_presentation_generated':False,'static_preview_only':True})
