# TrustWallet Presentation Studio

پروژهٔ Codex، مرحلهٔ اول: فقط ممیزی و آماده‌سازی.

- دستورالعمل دائمی: [AGENTS.md](AGENTS.md)
- گزارش اصلی: [analysis/audit-report.md](analysis/audit-report.md)
- متن کامل اسلایدها: [analysis/content-manifest.md](analysis/content-manifest.md)
- دادهٔ کامل: analysis/content-manifest.json و analysis/animation-inventory.json
- شش Skill: .agents/skills/
- پیش‌نمایش ایستا: previews/original.pdf و PNGهای۳۳صفحه
- صحت منبع: qa/source-integrity.json
- ابزار بازتولید ممیزی: production/scripts/audit.py و finalize_audit.py

هیچ نسخهٔ طراحی‌شده یا اصلاح‌شدهٔ PPTX تولید نشده است. source شامل دو کپی یکسان مرجع است؛ output عمداً خالی است. هیچ نصب یا انتشار عمومی انجام نشده است. پیش از مرحلهٔ بعد تأیید کاربر لازم است.
