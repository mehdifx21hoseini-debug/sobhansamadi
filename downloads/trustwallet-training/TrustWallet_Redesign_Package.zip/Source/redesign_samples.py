from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile,ZIP_DEFLATED
from io import BytesIO
import json,hashlib
from lxml import etree as E
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN,MSO_ANCHOR
R=Path(__file__).resolve().parents[2];source=R/'source/original.pptx';p=Presentation(source)
P='http://schemas.openxmlformats.org/presentationml/2006/main';A='http://schemas.openxmlformats.org/drawingml/2006/main';ns={'p':P,'a':A}
W=13.333333;H=7.5
NAVY='111E32';INK='17283F';BLUE='355CFF';MINT='54E3BB';WARM='FAFBF7';MUTED='637183';LINE='DDE4E8';LIGHT='EAF0F3';CORAL='FF9D89'
proto=Presentation();proto.slide_width=Inches(W);proto.slide_height=Inches(H)
logs=[];timingparts={}
def rect(s,x,y,w,h,fill,radius=False,line=None,name='design'):
 a=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h));a.name=name
 a.fill.solid();a.fill.fore_color.rgb=RGBColor.from_string(fill);a.line.fill.background()
 if radius:a.adjustments[0]=.16
 if line:a.line.color.rgb=RGBColor.from_string(line);a.line.width=Pt(.6)
 return a
def circle(s,x,y,w,fill):
 a=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x),Inches(y),Inches(w),Inches(w));a.fill.solid();a.fill.fore_color.rgb=RGBColor.from_string(fill);a.line.fill.background();return a
def tx(s,key,txt,x,y,w,h,size=20,color=INK,bold=False,center=False):
 a=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));a.name=key;tf=a.text_frame;tf.clear();tf.margin_left=0;tf.margin_right=0;tf.margin_top=0;tf.margin_bottom=0;tf.word_wrap=True
 for i,line in enumerate(txt.split('\n')):
  par=tf.paragraphs[0] if i==0 else tf.add_paragraph();par.alignment=PP_ALIGN.CENTER if center else PP_ALIGN.RIGHT;par._p.get_or_add_pPr().set('rtl','0' if center and all(ord(c)<128 for c in line) else '1');par.space_before=Pt(0);par.space_after=Pt(0);par.line_spacing=1.08
  run=par.add_run();run.text=line;f=run.font;f.name='Vazirmatn';f.size=Pt(size);f.bold=bold;f.color.rgb=RGBColor.from_string(color)
  cs=E.SubElement(run._r.get_or_add_rPr(),'{'+A+'}cs');cs.set('typeface','Vazirmatn')
 return a
def pic(s,original,name,x,y,w,h=None):
 old=next(a for a in original.shapes if a.name==name);e=deepcopy(old._element)
 cn=e.find('p:nvPicPr/p:cNvPr',ns);cn.set('id',str(s.shapes._next_shape_id));cn.set('name','IMAGE_'+name)
 t=e.find('p:spPr/a:xfrm',ns);off=t.find('a:off',ns);ex=t.find('a:ext',ns)
 for k,v in [('x',x),('y',y)]:off.set(k,str(round(v*914400)))
 if h is None:h=w*old.height/old.width
 for k,v in [('cx',w),('cy',h)]:ex.set(k,str(round(v*914400)))
 s.shapes._spTree.insert_element_before(e,'p:extLst');return s.shapes[-1]
def textmap(original):return {a.name:a.text for a in original.shapes if a.has_text_frame and a.text.strip()}
def header(s,original,dark=False):
 if dark:rect(s,.5,.20,2.9,.52,'FFFFFF',True)
 pic(s,original,'!!barLogo',.70,.25,2.40,.44)
 rect(s,11.95,.34,.65,.055,MINT if dark else BLUE,True)
def footer(s,m,dark=False):
 color='B6C7D7' if dark else MUTED;rect(s,.65,6.96,12.0,.008,'2B3A50' if dark else LINE)
 for txt,x,w in [('SOBHANSAMADI.COM',.68,2.0),('SOBHANSAMADI',2.95,1.65),('SOBHANSFOREX',4.90,1.65)]:tx(s,'BRAND_'+txt,txt,x,7.10,w,.2,9,color,False,True)
 tx(s,'BRAND_TEACHER','مدرس: تریدر سبحان صمدی',8.0,7.05,3.8,.3,11,color)
 tx(s,'pageNum',m['pageNum'],12.05,7.04,.55,.35,14,MINT if dark else BLUE,True,True)
def put(s,m,key,*args,**kw):return tx(s,key,m[key],*args,**kw)
def targetids(items):return [a.shape_id for a in items]
def timing(groups):
 def el(par,tag,**kw):return E.SubElement(par,'{'+P+'}'+tag,**{k:str(v) for k,v in kw.items()})
 t=E.Element('{'+P+'}timing');root=el(el(el(t,'tnLst'),'par'),'cTn',id=1,dur='indefinite',restart='never',nodeType='tmRoot');seq=el(el(root,'childTnLst'),'seq',concurrent=1,nextAc='seek');main=el(seq,'cTn',id=2,dur='indefinite',nodeType='mainSeq');lst=el(main,'childTnLst');uid=3
 for group in groups:
  ct=el(el(lst,'par'),'cTn',id=uid,fill='hold');uid+=1;el(el(ct,'stCondLst'),'cond',delay='indefinite');inner=el(el(el(ct,'childTnLst'),'par'),'cTn',id=uid,fill='hold');uid+=1;el(el(inner,'stCondLst'),'cond',delay=0);effects=el(inner,'childTnLst')
  for j,sid in enumerate(group):
   c=el(el(effects,'par'),'cTn',id=uid,presetID=10,presetClass='entr',presetSubtype=0,fill='hold',nodeType='clickEffect' if j==0 else 'withEffect');uid+=1;el(el(c,'stCondLst'),'cond',delay=0);children=el(c,'childTnLst');st=el(children,'set');beh=el(st,'cBhvr');el(beh,'cTn',id=uid,dur=1,fill='hold');uid+=1;el(el(beh,'tgtEl'),'spTgt',spid=sid);el(el(beh,'attrNameLst'),'attrName').text='style.visibility';el(el(st,'to'),'strVal',val='visible');fade=el(children,'animEffect',transition='in',filter='fade');b=el(fade,'cBhvr');el(b,'cTn',id=uid,dur=350,fill='hold');uid+=1;el(el(b,'tgtEl'),'spTgt',spid=sid)
 for n,ev in [('prevCondLst','onPrev'),('nextCondLst','onNext')]:el(el(el(seq,n),'cond',evt=ev,delay=0),'tgtEl').append(E.Element('{'+P+'}sldTgt'))
 return t
# Sample9 — editorial split, navy comparison stage, open typography and three rules.
o=p.slides[8];m=textmap(o);s=proto.slides.add_slide(proto.slide_layouts[6]);rect(s,0,0,W,H,WARM);header(s,o);footer(s,m)
rect(s,.60,1.18,6.40,5.45,NAVY,True);rect(s,.88,1.48,.08,4.80,BLUE,True)
put(s,m,'eyebrow',10.25,.87,2.35,.38,17,BLUE,True)
put(s,m,'title',7.45,1.38,5.15,1.40,34,INK,True)
examplegroups=[]
for good,y in [(True,2.00),(False,4.15)]:
 prefix='ok' if good else 'no';items=[]
 for suffix,x,icon in [('A',4.10,prefix+'AL'),('B',1.10,prefix+'BL')]:
  items.append(rect(s,x,y,2.37,.83,'FFFFFF',True));items.append(pic(s,o,icon,x+1.72,y+.20,.42,.42));items.append(put(s,m,prefix+suffix+'T',x+.16,y+.24,1.42,.37,20,INK,True,True))
 items.append(put(s,m,'eq' if good else 'ne',3.53,y+.13,.45,.51,31,MINT if good else CORAL,True,True));items.append(put(s,m,prefix+'T',1.15,y+1.10,5.25,.65,20,MINT if good else CORAL,True,True));examplegroups.append(targetids(items))
tips=[]
for key,icon,y in [('t_84','img_83',3.05),('t_87','img_86',4.20),('t_90','img_89',5.45)]:
 circle(s,12.02,y+.05,.52,'E8F5F1');a=pic(s,o,icon,12.15,y+.18,.26,.26);b=put(s,m,key,7.55,y,4.18,.90,17.5,INK,False);tips.extend([a,b]);rect(s,7.55,y+1.0,5.03,.009,LINE)
timingparts[9]=timing(examplegroups+[targetids(tips)])
# Sample19 — dark security lesson, faithful phone and magazine-like hierarchy.
o=p.slides[18];m=textmap(o);s=proto.slides.add_slide(proto.slide_layouts[6]);rect(s,0,0,W,H,NAVY);header(s,o,True);footer(s,m,True)
rect(s,.62,.88,3.98,5.83,'E7EFEF',True);pic(s,o,'PHONE_PHOTO_seed',1.00,.95,3.20)
put(s,m,'title',5.15,1.02,7.43,.90,31,'FFFFFF',True);put(s,m,'subt',5.15,2.00,7.43,.48,18,MINT)
put(s,m,'LESSON_TEXT_گام ۵ از ۹',10.0,2.72,2.55,.32,13,'BBCAD8')
action=rect(s,5.36,2.65,3.30,.60,BLUE,True);actionlabel=put(s,m,'LESSON_TEXT_Secret phrase',5.48,2.76,3.06,.36,20,'FFFFFF',True,True)
groups=[[action.shape_id,actionlabel.shape_id]]
for j,y in [(1,3.57),(2,5.18)]:
 items=[rect(s,5.17,y,7.40,1.39 if j==1 else 1.27,'1C2D45',True),circle(s,11.89,y+.19,.43,MINT)]
 nk='LESSON_TEXT_'+('۱' if j==1 else '۲');items.append(put(s,m,nk,11.89,y+.21,.43,.36,16,NAVY,True,True))
 tk='LESSON_TEXT_ترتیب کلمات را دقیق نگه داری' if j==1 else 'LESSON_TEXT_این کلمات را به هیچ‌کس ندهید';dk='LESSON_TEXT_کلمات را به‌ترتیب روی کاغذ ب' if j==1 else 'LESSON_TEXT_از آن عکس نگیرید و آنلاین ذخ'
 items.append(put(s,m,tk,5.48,y+.17,6.02,.39,21,'FFFFFF',True));items.append(put(s,m,dk,5.48,y+.67,6.03,.55,16,'CDD7E3'));groups.append(targetids(items))
timingparts[19]=timing(groups)
# Sample28 — warm-white process cards, electric-blue path and floating icon medallions.
o=p.slides[27];m=textmap(o);s=proto.slides.add_slide(proto.slide_layouts[6]);rect(s,0,0,W,H,WARM);header(s,o);footer(s,m)
put(s,m,'title',6.45,.98,6.15,.80,40,INK,True);put(s,m,'subt',.75,1.96,11.82,.68,18,MUTED)
groups=[]
for j,(num,title,desc,icon) in enumerate([('t_160','t_161','t_162','img_158'),('t_165','t_166','t_167','img_163'),('t_171','t_172','t_173','img_169'),('t_176','t_177','t_178','img_174')]):
 x=9.83-j*3.03;items=[rect(s,x,2.99,2.65,2.54,'FFFFFF',True,LINE),rect(s,x+.18,2.99,2.29,.045,BLUE,True)]
 items.append(put(s,m,num,x+.20,3.13,.45,.48,24,BLUE,True,True));items.append(circle(s,x+.85,3.40,.96,NAVY));items.append(pic(s,o,icon,x+1.08,3.63,.50,.50));items.append(put(s,m,title,x+.14,4.58,2.37,.43,22,INK,True,True));items.append(put(s,m,desc,x+.12,5.08,2.41,.35,16,MUTED,False,True));groups.append(targetids(items))
 if j<3:
  a=s.shapes.add_shape(MSO_SHAPE.CHEVRON,Inches(x-.31),Inches(3.79),Inches(.20),Inches(.22));a.rotation=180;a.fill.solid();a.fill.fore_color.rgb=RGBColor.from_string(BLUE);a.line.fill.background()
b=rect(s,.75,5.98,11.82,.65,NAVY,True);t=put(s,m,'bandT',.96,6.13,11.40,.38,17,'FFFFFF',True,True);groups.append([b.shape_id,t.shape_id]);timingparts[28]=timing(groups)
# Surgical transplant: only3 slide parts replaced; original relationships and real media remain.
dest=R/'output/TrustWallet_Redesign_Samples.pptx';replacements={}
for idx,num in enumerate([9,19,28]):
 proto_s=proto.slides[idx];replacements[num]=deepcopy(proto_s.shapes._spTree)
 # ensure original source educational text shapes retained exactly, aside from added brand text
 original=textmap(p.slides[num-1]);new={a.name:a.text for a in proto_s.shapes if a.has_text_frame and a.text.strip()}
 assert all(new.get(k)==v for k,v in original.items()),[(k,v,new.get(k)) for k,v in original.items() if new.get(k)!=v]
with ZipFile(source) as z,ZipFile(dest,'w',ZIP_DEFLATED) as out:
 for it in z.infolist():
  data=z.read(it.filename)
  for num in [9,19,28]:
   if it.filename==f'ppt/slides/slide{num}.xml':
    root=E.fromstring(data);cs=root.find('p:cSld',ns);old=cs.find('p:spTree',ns);cs.replace(old,replacements[num])
    bg=cs.find('p:bg',ns)
    if bg is not None:cs.remove(bg)
    for n in list(root):
     if E.QName(n).localname in ['timing','transition'] or (E.QName(n).localname=='AlternateContent' and n.xpath('.//p:timing|.//p:transition',namespaces=ns)):root.remove(n)
    tr=E.Element('{'+P+'}transition',spd='fast',advClick='1');E.SubElement(tr,'{'+P+'}fade');root.append(tr);root.append(timingparts[num]);ext=root.find('p:extLst',ns)
    if ext is not None:root.remove(ext);root.append(ext)
    data=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
  out.writestr(deepcopy(it),data)
(R/'qa/redesign-build.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'modified_slides':[9,19,28],'new_palette':[NAVY,BLUE,MINT,WARM],'native_editable':True,'timing_policy':'Sample animations rebuilt as native sequential Fade for new object identities; original30 other timings preserved. No loops or motion paths added.','real_ui':'Original embedded phone photo bytes and crop retained; no UI reconstruction','original_notes_relationships_media_fonts':'all unchanged byte for byte'},indent=2))
print(dest)
