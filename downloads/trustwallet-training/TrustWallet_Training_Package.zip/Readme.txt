ابتدا فایل ZIP را Extract کنید.
TrustWallet_Presentation.pptx: نسخه تصویری برای ارائه؛ بدون نیاز به فونت. متن داخل اسلایدها قابل ویرایش نیست.
TrustWallet_Editable.pptx: نسخه قابل ویرایش؛ برای حفظ ظاهر، فونت Vazirmatn را نصب کنید.
TrustWallet_Training.pdf: نسخه مرور و ارائه PDF.
