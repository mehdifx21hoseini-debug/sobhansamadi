from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from copy import deepcopy
import hashlib,json,re
from lxml import etree as E
R=Path(__file__).resolve().parents[2];P='http://schemas.openxmlformats.org/presentationml/2006/main';A='http://schemas.openxmlformats.org/drawingml/2006/main';ns={'p':P,'a':A};EMU=914400
source=R/'source/original.pptx';output=R/'output/TrustWallet_Three_Samples.pptx';log=[]
def child(par,tag,**attrs):pre,local=tag.split(':');return E.SubElement(par,'{'+({'p':P,'a':A}[pre])+'}'+local,**{k:str(v) for k,v in attrs.items()})
def shape(root,name):return next(s for s in root.xpath('./p:cSld/p:spTree/*',namespaces=ns) if s.xpath('./p:nvSpPr/p:cNvPr/@name|./p:nvPicPr/p:cNvPr/@name|./p:nvCxnSpPr/p:cNvPr/@name',namespaces=ns)==[name])
def geom(root,name,x=None,y=None,w=None,h=None,dx=0,dy=0):
 s=shape(root,name);t=s.find('.//a:xfrm',ns);o=t.find('a:off',ns);ext=t.find('a:ext',ns)
 old=[int(o.get('x')),int(o.get('y')),int(ext.get('cx')),int(ext.get('cy'))]
 vals=[round(x*EMU) if x is not None else old[0]+round(dx*EMU),round(y*EMU) if y is not None else old[1]+round(dy*EMU),round(w*EMU) if w is not None else old[2],round(h*EMU) if h is not None else old[3]]
 for e,k,v in [(o,'x',vals[0]),(o,'y',vals[1]),(ext,'cx',vals[2]),(ext,'cy',vals[3])]:e.set(k,str(v))
 log.append({'shape':name,'before':old,'after':vals})
def card(root,name,x,y,w,h):
 tree=root.find('p:cSld/p:spTree',ns);sid=max(int(n.get('id')) for n in root.xpath('//p:cNvPr',namespaces=ns))+1
 s=E.Element('{'+P+'}sp');nv=child(s,'p:nvSpPr');child(nv,'p:cNvPr',id=sid,name=name);child(nv,'p:cNvSpPr');child(nv,'p:nvPr');sp=child(s,'p:spPr');t=child(sp,'a:xfrm');child(t,'a:off',x=round(x*EMU),y=round(y*EMU));child(t,'a:ext',cx=round(w*EMU),cy=round(h*EMU));g=child(sp,'a:prstGeom',prst='roundRect');av=child(g,'a:avLst');child(av,'a:gd',name='adj',fmla='val 9000');child(child(sp,'a:solidFill'),'a:srgbClr',val='F3FCF9');ln=child(sp,'a:ln',w=6350);child(child(ln,'a:solidFill'),'a:srgbClr',val='E2EBEE')
 # insert beneath teaching content, above original background decorations
 first=next(i for i,a in enumerate(tree) if a.xpath('./p:nvSpPr/p:cNvPr[@name="title" or @name="eyebrow"]',namespaces=ns));tree.insert(first,s)
 log.append({'added_shape':name,'id':sid,'bounds_in':[x,y,w,h]})
with ZipFile(source) as z,ZipFile(output,'w',ZIP_DEFLATED) as out:
 for it in z.infolist():
  data=z.read(it.filename)
  if it.filename in ['ppt/slides/slide9.xml','ppt/slides/slide19.xml','ppt/slides/slide28.xml']:
   root=E.fromstring(data);start=len(log)
   if it.filename.endswith('slide9.xml'):
    for k,(txt,disc,icon,y) in enumerate([('t_84','card_82','img_83',3.42),('t_87','card_85','img_86',4.48),('t_90','card_88','img_89',5.54)],1):
     card(root,'SAMPLE9_TIP_SURFACE_'+str(k),.45,y-.08,5.30,.92);geom(root,txt,x=.68,y=y,w=4.12,h=.78);geom(root,disc,x=5.0,y=y+.08);geom(root,icon,x=5.13,y=y+.21)
    for name in ['okA','okAL','okAT','okB','okBL','okBT','eq']:geom(root,name,dy=.12)
    geom(root,'okT',y=2.85)
    for name in ['noA','noAL','noAT','noB','noBL','noBT','ne']:geom(root,name,dy=.05)
    geom(root,'noT',y=5.12)
   elif it.filename.endswith('slide19.xml'):
    geom(root,'LESSON_ACTION_FRAME',y=2.62,h=.95);geom(root,'LESSON_ACTION',y=2.79);geom(root,'LESSON_TEXT_Secret phrase',y=2.86)
    for k in [1,2]:
     delta=.08 if k==1 else .14
     for name in [f'LESSON_CARD_{k}',f'LESSON_BADGE_{k}',f'LESSON_TEXT_{"۱" if k==1 else "۲"}']:geom(root,name,dy=delta)
     prefix=['LESSON_TEXT_ترتیب کلمات را دقیق نگه داری','LESSON_TEXT_کلمات را به‌ترتیب روی کاغذ ب'] if k==1 else ['LESSON_TEXT_این کلمات را به هیچ‌کس ندهید','LESSON_TEXT_از آن عکس نگیرید و آنلاین ذخ']
     for name in prefix:geom(root,name,dy=delta,h=.40 if name==prefix[0] else .55)
   else:
    for j,(title,desc) in enumerate([('t_161','t_162'),('t_166','t_167'),('t_172','t_173'),('t_177','t_178')]):
     x=9.80-2.97*j;card(root,'SAMPLE28_CAPTION_SURFACE_'+str(j),x,4.37,2.60,1.03);geom(root,title,y=4.47);geom(root,desc,y=4.96)
    geom(root,'route_157',y=3.45)
   for e in log[start:]:e['slide_part']=it.filename
   original_bytes=z.read(it.filename)
   data=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
   for tag in [b'timing',b'transition']:
    pattern=rb'<p:'+tag+rb'\b[^>]*>.*?</p:'+tag+rb'>'
    old=re.findall(pattern,original_bytes,re.S);new=re.findall(pattern,data,re.S)
    assert len(old)==len(new)
    for before,after in zip(old,new):data=data.replace(after,before,1)
  out.writestr(deepcopy(it),data)
(R/'qa/phase3-change-log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
print('Created33-slide review deck; only9/19/28 changed;',len(log),'logged edits')
