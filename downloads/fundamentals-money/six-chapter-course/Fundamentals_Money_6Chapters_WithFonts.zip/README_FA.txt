دورهٔ فاندامنتال بازارهای مالی و فارکس
تریدر سبحان صمدی

نسخهٔ شش‌فصلی: ۴۹ اسلاید، شامل نقشهٔ دوره، ۴۷ صفحهٔ آموزشی و جمع‌بندی.
متن‌ها، کارت‌ها، نمودارها و فلوچارت‌ها در پاورپوینت قابل‌ویرایش هستند؛ تصویرهای مفهومی نیز مستقل و قابل‌جایگزینی‌اند.
تعریف‌ها و توضیح‌ها داخل اسلاید باقی مانده‌اند. متن نسخهٔ مرجع و لینک منابع در یادداشت مدرس صفحات مرتبط ثبت شده است.

فونت:
پیش از بازکردن پاورپوینت روی رایانهٔ جدید، سه فایل TTF پوشهٔ Fonts را نصب کنید و سپس پاورپوینت را دوباره باز کنید. وجود فونت در ZIP به‌تنهایی باعث نصب خودکار نمی‌شود.
PDF برای پیش‌نمایش به نصب فونت نیاز ندارد.

بازهٔ فصل‌ها در نسخهٔ جدید:
۱. نیاز به پول: صفحات ۲ تا ۸
۲. تکامل تاریخی: صفحات ۹ تا ۱۷
۳. بانکداری: صفحات ۱۸ تا ۲۳
۴. خلق پول مدرن: صفحات ۲۴ تا ۳۰
۵. بانک مرکزی و سیاست پولی: صفحات ۳۱ تا ۳۹
۶. تورم، اوراق و بازار ارز: صفحات ۴۰ تا ۴۸
صفحهٔ ۱ نقشهٔ دوره و صفحهٔ ۴۹ جمع‌بندی است.

اصلاح‌های علمی کلیدی:
- روایت تهاتر و امانت‌داری طلا، تاریخ یکسان و قطعی همهٔ جوامع معرفی نشده است.
- بانک انگلستان ۱۶۹۴ یک نمونهٔ تاریخی است، نه نخستین بانک جهان.
- پول نقد، ذخایر بانک‌ها و سپردهٔ مشتری از هم تفکیک شده‌اند.
- ایجاد وام با ثبت هم‌زمان دارایی و بدهی توضیح داده شده؛ وام‌گیری مساوی افزایش ثروت خالص نیست.
- وظایف بانک‌های مرکزی تابع قانون کشور است؛ همگی مأموریت یکسان ندارند.
- رابطهٔ حجم پول و تورم، و نرخ بهره و ارز، قطعی و تک‌علتی بیان نشده است.
- مثال‌های شاخص قیمت و بازده جاری فرضی‌اند؛ بازده جاری از بازده تا سررسید متمایز شده است.
- هدف بلندمدت ۲٪ فدرال رزرو بر مبنای PCE از CPI تفکیک شده است.

کنترل کیفیت:
تمام صفحات به PDF تبدیل و از نظر ظاهری مرور شدند. اعتبارسنجی XML اسلایدها و آزمون محدودهٔ متن در رندر بدون خطا بود. تست مستقیم در نسخهٔ ویندوزی PowerPoint انجام نشده است.

نگاشت ۲۴ صفحهٔ مرجع به صفحات جدید:
1 → 2
2 → 3
3 → 4
4 → 5
5 → 6
6 → 7
7 → 8
8 → 9, 12
9 → 10, 12
10 → 11, 12
18 → 13, 24
11 → 14, 18
12 → 15, 18
13 → 16, 18
14 → 17, 18, 19, 20
16 → 20, 21, 22, 33
15 → 21
17 → 23
19 → 24, 25, 29
20 → 26
21 → 27
22 → 28, 29, 30, 34
23 → 29, 31, 33, 34, 35
24 → 32

منابع رسمی:
money: https://www.bankofengland.co.uk/quarterly-bulletin/2014/q1/money-in-the-modern-economy-an-introduction
creation: https://www.bankofengland.co.uk/quarterly-bulletin/2014/q1/money-creation-in-the-modern-economy
history: https://www.bankofengland.co.uk/quarterly-bulletin/1969/q2/the-bank-of-england-note---a-short-history
earlynotes: https://www.bankofengland.co.uk/museum/online-collections/blog/our-earliest-bank-of-england-note
boehistory: https://www.bankofengland.co.uk/about/history
measures: https://www.federalreserve.gov/faqs/money_12845.htm
aggregates: https://www.federalreserve.gov/releases/h6/current/default.htm
policy: https://www.federalreserve.gov/aboutthefed/fedexplained/monetary-policy.htm
goals: https://www.federalreserve.gov/faqs/what-economic-goals-does-federal-reserve-seek-to-achieve-through-monetary-policy.htm
ecbgoals: https://www.ecb.europa.eu/mopo/intro/role/html/index.en.html
supervision: https://www.federalreserve.gov/aboutthefed/fedexplained/supervision-regulation.htm
balancesheet: https://www.federalreserve.gov/monetarypolicy/bst_fedsbalancesheet.htm
liabilities: https://www.federalreserve.gov/monetarypolicy/bst_frliabilities.htm
reserves: https://www.federalreserve.gov/monetarypolicy/iorb-faqs.htm
transmission: https://www.ecb.europa.eu/mopo/intro/transmission/html/index.en.html
operations: https://www.newyorkfed.org/markets/domestic-market-operations/monetary-policy-implementation
ecbtools: https://www.suomenpankki.fi/en/Monetary-policy/implementation-of-monetary-policy/monetary-policy-instruments/
cpi: https://www.bls.gov/cpi/questions-and-answers.htm
cpicalc: https://www.bls.gov/opub/hom/cpi/calculation.htm
velocity: https://www.stlouisfed.org/on-the-economy/2014/september/what-does-money-velocity-tell-us-about-low-inflation-in-the-us
bonds: https://www.investor.gov/introduction-investing/investing-basics/investment-products/bonds-or-fixed-income-products/bonds
bondrisk: https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-86
yield: https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins/what-are
